---
name: Suggest a new linter or fixer
labels: new tool
about: Suggest a new tool ALE can officially integrate with.

---

<!--
  Write "Add support for foobar" as the issue title, or similar.

  Fill out the details below.
-->

**Name:** foobar
**URL:** https://foo.bar.com

<!--
  Write a description of the tool, and add any other information you think might
  be helpful. Consider creating a pull request to add support for the tool
  yourself.
-->
